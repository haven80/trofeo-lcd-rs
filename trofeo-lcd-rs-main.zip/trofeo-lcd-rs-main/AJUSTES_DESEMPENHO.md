# Trofeo LCD 2.30 — Ajustes de desempenho

Esta versão adiciona três opções em **Settings > System** (exigem reiniciar o Trofeo LCD depois de salvar):

1. `performance_max_fps` — limite global de renderização, de 0 a 30. `0` mantém o comportamento adaptativo anterior. Valores de 1 a 30 limitam todas as telas e animações, inclusive as que solicitam mais quadros.
2. `performance_sensor_interval_ms` — intervalo de atualização dos sensores, de 250 a 5000 ms. Padrão: 500 ms. Valores maiores reduzem a frequência de consultas de CPU, memória, GPU, rede e disco.
3. `performance_spectrum_fps` — frequência de recálculo FFT, de 5 a 60 por segundo. Padrão: 30. A captura WASAPI continua ativa; apenas o processamento FFT é espaçado. O limite global de FPS continua controlando a renderização.

## Sugestões iniciais de teste

- Referência: FPS 0, sensores 500 ms, Spectrum 30/s.
- Equilibrado: FPS 20, sensores 1000 ms, Spectrum 20/s.
- Econômico: FPS 10, sensores 2000 ms, Spectrum 10/s.
- Economia máxima: FPS 5, sensores 5000 ms, Spectrum 5/s.

Os perfis acima são combinações sugeridas para teste, não garantias de um percentual específico de economia. Compare o consumo de CPU e a resposta visual em cada configuração.

A seleção individual WASAPI L/R/MIX, os controles Compressor/Ganho e a captura adicional `System (Elgato Virtual Audio)` foram preservados.


## Ajustes independentes dos Spectrums L/R/MIX

Em **Settings > Cards**, cada Spectrum possui configurações próprias (salvas em `trofeo.conf`):

- `cards_spectrum_<canal>_fft`: resolução 256, 512, 1024 ou 2048. Resoluções maiores distinguem frequências próximas, mas aumentam o custo e a latência.
- `cards_spectrum_<canal>_bars`: 16 a 96 barras.
- `cards_spectrum_<canal>_smoothing`: 0 (resposta imediata) a 100 (suavização forte).

Os canais são `left`, `right` e `mix`. A captura WASAPI permanece contínua e independente por dispositivo. O programa registra em `trofeo_lcd_runtime.log` o tempo de processamento de cada Spectrum, em milissegundos por atualização, aproximadamente uma vez por segundo enquanto os cards Spectrum estão ativos.

O processamento foi otimizado para reutilizar o buffer FFT, a janela Hann, os intervalos de frequência e o vetor de barras, evitando as alocações temporárias que eram feitas em cada quadro.
