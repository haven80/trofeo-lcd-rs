# Trofeo LCD 2.30 — Spectrum no layout Cards

Esta versão adiciona um cartão de Spectrum ao layout Cards, mantendo o mesmo desenho externo dos cartões originais: fundo em gradiente, bordas arredondadas, contorno, tipografia e espaçamento.

## Como ativar

1. Abra o `trofeo.conf` que fica na mesma pasta do `trofeo_lcd.exe` (ou no diretório de onde o programa é iniciado).
2. Defina `layout = cards`.
3. Localize a linha `cards =` e inclua `spectrum`. Exemplo:

```ini
layout = cards
cards = clock | cpu, gpu | ram, disk | spectrum, spectrum_l, spectrum_r, spectrum_mix
cards_spectrum_channel = stereo
cards_spectrum_style = bars
```

Se já existir uma linha `cards =`, substitua-a ou adapte-a para não manter duas definições conflitantes.

## Opções do Spectrum

Além do cartão `spectrum` tradicional, agora existem três cartões independentes que podem ser adicionados diretamente em `cards`:
- `spectrum_l`: mostra somente o canal esquerdo.
- `spectrum_r`: mostra somente o canal direito.
- `spectrum_mix`: mistura L/R em um único gráfico.

Esses três cartões não dependem de `cards_spectrum_channel`; cada um mantém sua função fixa. O cartão `spectrum` continua respeitando essa configuração, incluindo `stereo`.


`cards_spectrum_channel`:
- `combined`: mistura os canais L/R em um gráfico.
- `left`: somente canal esquerdo.
- `right`: somente canal direito.
- `stereo`: dois gráficos lado a lado, L e R (padrão).

`cards_spectrum_style`:
- `bars`: barras contínuas (padrão).
- `led`: barras segmentadas.
- `mirror`: barras simétricas em torno do centro.

A captura agora preserva os canais L/R no buffer compartilhado. Os demais consumidores de áudio continuam recebendo o sinal mono combinado para manter o comportamento anterior.

## Compilar e iniciar

Execute `instalar_e_rodar.bat` com duplo clique. Ele prepara Rust/Build Tools quando necessário, compila os binários e inicia `trofeo_lcd.exe`.

Arquivos de diagnóstico:
- `compilacao.log`: saída completa da instalação e compilação.
- `erro.txt`: cópia do diagnóstico quando a instalação/compilação falha.
- `trofeo_lcd_runtime.log`: saída do programa após iniciar pelo BAT.

Se algo falhar, envie `erro.txt` e `compilacao.log`. Se o programa abrir mas o Spectrum apresentar comportamento incorreto, envie também `trofeo_lcd_runtime.log` e uma cópia do seu `trofeo.conf` (remova dados pessoais antes de compartilhar).

## Escopo de compatibilidade

A alteração foi limitada ao cartão Cards e à preservação dos canais de áudio na captura compartilhada. Deck, Orbit, Console e os demais renderizadores não receberam alterações visuais ou de layout. A compilação precisa ser validada no Windows do usuário; este ambiente de preparação não possui Rust/Cargo instalado para executar a compilação nativa.
