# Third-party notices

## Overlayed 0.6.2

This Trofeo LCD build contains an adaptation of the Discord RPC voice-state integration from **Overlayed 0.6.2** (https://github.com/overlayeddev/overlayed), copyright its respective contributors, licensed under **GNU Affero General Public License v3.0 (AGPL-3.0)**.

Adapted portions are located in `src/discord.rs`. The Trofeo Discord bridge follows the Overlayed 0.6.2 RPC flow: local Discord RPC WebSocket (`127.0.0.1:6463`), OAuth authorization using the Overlayed application ID, token exchange through `https://api.overlayed.dev/token`, and voice channel/user/speaking event subscriptions.

This integration only consumes Discord metadata and voice activity events. It does not join a voice media connection and does not capture, transmit, record, store, or analyze audio.

The complete AGPL-3.0 license is provided in `LICENSE`. Source modifications and this derivative work are distributed under AGPL-3.0. The Overlayed upstream project and its authors are not affiliated with or endorsing Trofeo LCD.
