# Teste – dispositivo de áudio do Spectrum no layout Cards

1. Extraia o ZIP inteiro para uma pasta do Windows.
2. Dê dois cliques em `instalar_e_rodar.bat` e aguarde a compilação e a abertura do Trofeo LCD.
3. Abra o configurador `trofeo_config.exe` na pasta `target\release` (ou abra o configurador que já acompanha sua instalação).
4. Na seção **Deck, Cards, Orbit and Console**, localize o grupo **Cards**.
5. Em **Cards Spectrum: audio device**, escolha:
   - **Audio output / Playback loopback** para capturar o áudio reproduzido por um dispositivo de saída; ou
   - **Audio input / Microphone** para capturar um microfone/dispositivo de entrada.
6. Selecione o dispositivo na segunda lista. A opção **System default** usa o dispositivo padrão do Windows.
7. Salve a configuração e reinicie o Trofeo LCD para aplicar a nova captura.
8. No layout Cards, adicione `spectrum`, `spectrum_l`, `spectrum_r` ou `spectrum_mix` e teste o áudio.

A captura escolhida para Cards é separada da captura usada pelo visualizador global/tela de música. Se escolher um microfone, fale ou reproduza som nele para testar.

Se ocorrer uma falha na compilação, envie `erro.txt` e `compilacao.log`. Se o programa abrir mas o Spectrum não reagir, envie também `trofeo_lcd_runtime.log` e `trofeo_lcd_runtime_error.log`.

**Nota:** a seleção individual de dispositivos WASAPI é implementada para Windows. Nesta versão, Linux continua usando o monitor de saída padrão; seleção de microfone no Linux ainda não está implementada.
